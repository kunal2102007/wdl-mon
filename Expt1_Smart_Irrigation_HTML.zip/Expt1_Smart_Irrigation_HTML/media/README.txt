Put your own files in this folder with these names:
  smart-irrigation.mp4     (video on media.html)
  water-conservation.mp3   (audio on media.html)
