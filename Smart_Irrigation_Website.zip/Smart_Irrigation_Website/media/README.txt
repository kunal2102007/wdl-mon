Put your own video and audio files in this folder with these names:
  irrigation.mp4   (used by the video player on media.html)
  awareness.mp3    (used by the audio player on media.html)
